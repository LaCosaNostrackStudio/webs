(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"LOGO ANIMADO PARA WEB canvas_atlas_1", frames: [[0,381,459,107],[0,0,275,183],[0,185,259,194]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_1 = function() {
	this.initialize(ss["LOGO ANIMADO PARA WEB canvas_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Mapadebits12 = function() {
	this.initialize(ss["LOGO ANIMADO PARA WEB canvas_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Mapadebits13 = function() {
	this.initialize(ss["LOGO ANIMADO PARA WEB canvas_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Símbolo5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A/ZWMMAAAgsXMA+zAAAMAAAAsXg");
	this.shape.setTransform(201,141.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Símbolo5, new cjs.Rectangle(0,0,402,284), null);


(lib.Símbolo3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1FB8C9").s().p("AgggCQCDAEiDABg");
	this.shape.setTransform(218.3125,864.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1ABEC9").s().p("AghgBQCIgCiIAGg");
	this.shape_1.setTransform(205.425,865.3278);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#60B2B2").s().p("AgdAFQAUgNAdgFIAKgBQAAAFgCACQgXARgiAFIAAgKg");
	this.shape_2.setTransform(354,816.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#33576F").s().p("AgYAKIAAgKQAPgPAYgDIAKgBIAAAKQAAAFgBABQgcAJgUAOIAAgKg");
	this.shape_3.setTransform(677.5,634.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#33566B").s().p("AgiAPIAAgKQATgZAogEIAKAAIAAAKQAAAFgCABIhDAhIAAgKg");
	this.shape_4.setTransform(683.5,630.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#255062").s().p("AgpAWQgDgCAAgFQAtgeAigIIAKgBIAAAKQgFAAgCADQgdAZgrALQgFAAgCgDg");
	this.shape_5.setTransform(670.5,637.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2A4E5F").s().p("AgsAUIAAgKIBQglQAEgCAFAAIAAAKQgFAAgCACQgjAfgvAQIAAgKg");
	this.shape_6.setTransform(691.5,626.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2A5361").s().p("AgYAIIAAgJQAYgKAZgGIAAAGQAAAFgBAAQgcAKgUANIAAgJg");
	this.shape_7.setTransform(721.5,609.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2C5064").s().p("AgsAUIAAgKQAjgXAsgOQAFgCAFAAIAAAKQAAAFgCABQguATgpAYIAAgKg");
	this.shape_8.setTransform(714.5,613.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2A5263").s().p("AhFAjIAAgKQA7goBGgcQAFgBAFAAIAAAKQAAAFgCABQhHAjhCAmIAAgKg");
	this.shape_9.setTransform(703,619.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#204D62").s().p("Ag4AdQAbgSgegOQA/gkAuAFIAKABIAAAKQgFAAgDACQguAmhBATQAAgFADgCg");
	this.shape_10.setTransform(733,602.5386);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#264D61").s().p("AgxAXIAAgKIAAgKQAwgoAzAGIAAAFQgFAAgDACQgpAhgyAYIAAgKg");
	this.shape_11.setTransform(744,596.8171);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#274C60").s().p("AgfAPQgDgDAAgFIBFgXIAAAEQgFABgBACQgRAYgkACQgFAAgCgCg");
	this.shape_12.setTransform(777.5,577.35);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#275067").s().p("AgkAYQgDgDAAgFQAhgxAkAJIAKABIAAAKQgFAAgCADQgXAbgnAJQgFAAgCgCg");
	this.shape_13.setTransform(786,572.4748);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D5263").s().p("AhFAjIAAgKQBJgwA5gUQAEgBAFAAIAAAKQAAAFgCABQhGAjhDAmIAAgKg");
	this.shape_14.setTransform(797,566.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#33596B").s().p("AgiAPIAAgKQAOgRAtgLIAKgBIAAAKQgFAAgDADQgYAYglAMIAAgKg");
	this.shape_15.setTransform(765.5,584.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2F586D").s().p("AgTAHIAAgJQAbgWAJAOQADADAAAFQgFAAgCACQgNALgTAGIAAgKg");
	this.shape_16.setTransform(771,581.4396);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2A5061").s().p("Ag7AZQBEg4ApgCIAKgBIAAAKQgFAAgDACQgvAmhAATIAAgKg");
	this.shape_17.setTransform(756,589.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#254E5F").s().p("AgiAPIAAgKQAagfAhACIAKAAIAAAKQAAAFgCABQgkAOgfATIAAgKg");
	this.shape_18.setTransform(807.5,560.5692);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2C5166").s().p("AgsAUIAAgKIAAgKQAogOAogOQAEgBAFAAIAAAKQgFAAgCACQgeAig0ANIAAgKg");
	this.shape_19.setTransform(815.5,556.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#204A5F").s().p("Ag7AeIAAgKIAAgKQA7goAygIIAKgBIAAAKQgFAAgDADQgxAng+AbIAAgKg");
	this.shape_20.setTransform(826,550.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#284F5F").s().p("AgYAKQAAgFACgBQAPgGgRgRQAYAAAYAFQABAAAAAFQgFAAgCACQgPAUgbAHIAAgKg");
	this.shape_21.setTransform(834.5,545.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1B495D").s().p("AgYAPIAAgKQAggwAPAeQACAEAAAFQAAAEgCACQgXAOgYAJIAAgKg");
	this.shape_22.setTransform(841.5,539.5804);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#265361").s().p("AgcAZQgGgCgFgGQAqgVAlgXIAAAFQAAAFgCADQgcAVgdAVQgFgBgEgCg");
	this.shape_23.setTransform(864,523.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#224F5F").s().p("AgSAUQgGgCgFgGQAdgSAegPIAAAEQAAAFgCADQgSARgTAPQgFgBgEgCg");
	this.shape_24.setTransform(874,514.85);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#244C5A").s().p("AgYASIAAgKQAYgUAZgOIAAAEQAAAGgCACQgUAYgbASIAAgKg");
	this.shape_25.setTransform(882.5,507.35);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#20485C").s().p("AgnAjIAAgKQAWg7AvgJIAKgBQAAAFgCAEQggAugtAiIAAgKg");
	this.shape_26.setTransform(890,499.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1E485B").s().p("AgOAbQAHgPgMgYQATgTALAHQAEACAFAAIAAAKQAAAFgCAEQgKASgRAMg");
	this.shape_27.setTransform(897,490.4058);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#244F5F").s().p("Ag2BNIAAgKIAAgKQAzhnA6goIAAAFQAAAEgCAFQgrBZhABGIAAgKg");
	this.shape_28.setTransform(904.5,480.35);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D5163").s().p("AgjBlQgEgOAAgOQAnheAohRIAAAQIgBAKQgVBhgvBIIAAAKQgFAAgBgCg");
	this.shape_29.setTransform(915,458.825);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2AC3D5").s().p("AgTgMQA8g1gfBgIgEABQgXAAgCgsg");
	this.shape_30.setTransform(679.0223,215.4151);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#27C4D0").s().p("AgGANQgMgHAHgUQAvAUglAJg");
	this.shape_31.setTransform(674.25,200.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#5AC7C7").s().p("AAZASQglgKgWgbQAnAKAcAWQACACAAAFQgFAAgFgCg");
	this.shape_32.setTransform(750.5,273.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#63BBC5").s().p("AAjAXQgvgOggghQAwAQAnAaQACACAAAFQgFAAgFgCg");
	this.shape_33.setTransform(765.5,281.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#6ACBC8").s().p("AAZATQglgLgWgbQAmALAcAVQADACAAAFQgFAAgFgBg");
	this.shape_34.setTransform(743.5,269.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#21C2D3").s().p("AgRgKQBLgYhCAxQgFAEgEAAQgIAAAIgdg");
	this.shape_35.setTransform(659.8346,183.2226);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#25C3CF").s().p("AgRACIAAgEQA3AFgfAAIgYgBg");
	this.shape_36.setTransform(662.8125,189.3722);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3C7075").s().p("AgXAPQgGgCgFgGQAmgKAfgNIAAAEQAAAFgCADQgSAQgdAFQgFAAgEgCg");
	this.shape_37.setTransform(489.5,739.35);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#03758C").s().p("EgXYAiNQiJpKh2pbQJlkaHTmtQDijQg7l6QgZikhchsQhchsh2hSIAAgKIAAgUQEbpjAMsVIAFAAIDaB8QACABAAAFQB4A8B2BAQACABAAAFQAWAcAnALQAEABAFAAQAVAcAnAKQAEACAFAAQAlANAfAVQACABAAAFQAgAiAxAOQAEACAFAAQJTEsH8GFQDICZB/DkQB/DngtFAQgFAfgRAIIAAgPQgnBQgpBeQAAAPAFAOQAAABAFAAQAAAFgCAEQgIALgKAKIAAgFQg7ApgzBoIAAAKIAAAKQgFAAgEgCQgLgHgUATQAMAZgHAPIAFAAQAAAFgCACQgIAIgKAFIgKABQgwAJgWA8IAAAKIAAAKQAAAFgCACQgDADgFAAIAAgFQgZAOgZAVIAAAKIAAAKQAAAFgCACQgNANgPAKIAAgFQgeAPgeAUQAFAFAGADQAEACAFAAQAAAFgCADQgUATgcANIAAgFQglAXgrAWQAFAFAGADQAEACAFAAQAAAFgCACQhTBDhfA4QAAgFgCgEQgPgeghAxIAAAKIAAAKQAAAFgCADQgIAGgKAGQAAgFgBAAQgYgFgZAAQARARgPAHQgCABAAAFIgKABQgyAIg8ApIAAAKIAAAKQgFAAgEABQgpAOgoAPIAAAKIAAAKIgKAAQgigDgaAhIAAAKQgFAAgEABQg5AUhKAxIAAAKIgJgBQglgJgiAyQAAAFADACQACADAFAAQAAAFgCABQgIAEgKAAIAAgFIhGAZQAAAFADADQACACAFAAQAAAFgCADQgIAGgKAGQAAgFgCgDQgKgOgcAWIAAAKIgKABQguALgOASIAAAKIgKABQgpAChFA5IAAAKQAAAFgCACQgDADgFAAIAAgFQgzgGgwApIAAAKIAAAKIgKgBQgugFhAAkQAeAPgbASQgDACAAAFQAAAFgCAEQgIALgUAAIAAgFQgZAGgZAJIAAAKQgFAAgEACQgtAOgkAYIAAAKQgFAAgEABQhIAcg7ApIAAAKQgFAAgEACIhRAmIAAAKIgKAAQgoAEgUAaIAAAKIgKABQgZADgPAQIAAAKIgJABQgjAIguAfQAAAFADACQACADAFAAQAAAFgCABQlXDClZC+QgFAAAAgBg");
	this.shape_38.setTransform(747.1733,460.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#4F9EA3").s().p("AgsAUIAAgKQAogTAogSQAEgCAFAAIAAAKQAAAFgCABQguATgpAYIAAgKg");
	this.shape_39.setTransform(450.5,762.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#4D9EA1").s().p("AgiAPIAAgKQAbgRAhgKQAEgCAFAAIAAAKQgFAAgCADQgWAagoAKIAAgKg");
	this.shape_40.setTransform(458.5,757.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#489BA0").s().p("AgiAPIAAgKQAegOAegNQAEgCAFAAIAAAKQAAAFgCABQgkAOgfATIAAgKg");
	this.shape_41.setTransform(465.5,753.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#51A1A8").s().p("AgxAUIAAgKQAigUAkgRQAEgCAFAAIAKAAIAKAAQAAAFgDABQgsAfg0AWIAAgKg");
	this.shape_42.setTransform(474,749.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#61AEB4").s().p("AgYAKIAAgKQAUgJATgIQAFgCAFAAQAAAFgDABQgYAPgWASIAAgKg");
	this.shape_43.setTransform(410.5,785.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#53A2A8").s().p("AgdAIQAdgPAegKIAAAGQAAAEgCABQgcANgdAKIAAgJg");
	this.shape_44.setTransform(418,780.35);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#4DA0A3").s().p("AhFAeQBBgiBBghQAEgCAFAAIAAAKQAAAFgCABQhDAihGAdIAAgKg");
	this.shape_45.setTransform(432,772.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#51A1A7").s().p("AgiAPIAAgKQAegPAdgMQAFgCAFAAIAAAKQgFAAgCADQgXAagnAKIAAgKg");
	this.shape_46.setTransform(442.5,766.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#087987").s().p("AAFKKIgJAAQAQhrgoi5QhqnThamuIAAgKQBigqBTg4QAEgCAFAAQCJJGB5JVIABAKQgFAAgCADQgVAYgqADIAAgFQgfAOgnALQAFAFAGADQAEACAFAAQAAAFgCABQgrAYgtAUIgKAAg");
	this.shape_47.setTransform(477.5,681.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#28C5D2").s().p("AgIASQgEgVgCgcQA3AHgtA4g");
	this.shape_48.setTransform(475.5496,579.325);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#26C2D2").s().p("AgMgGQAzgGgzAUg");
	this.shape_49.setTransform(459.3,523.7571);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#2ABAD8").s().p("AgCAOQgPgGACgaQApAlgNAAQgEAAgLgFg");
	this.shape_50.setTransform(457.5911,513.0372);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#20C1CC").s().p("AgJgJQAoASgoABg");
	this.shape_51.setTransform(462.025,513.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#22C2D0").s().p("AgGAWQgKgRAHgkQAnAzgeAMg");
	this.shape_52.setTransform(454.0151,498.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#20BFD0").s().p("AgEARQgIgPACgaQAmgCgcAzg");
	this.shape_53.setTransform(462.09,482.5963);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#1FC2CC").s().p("AgIA0QgBgCgFAAIAAhjIAAgKQA0BWgqAhg");
	this.shape_54.setTransform(459.4507,496.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#20BECC").s().p("AgPhAIgBgKQAyAUgaCAQAAABgFAAIgSiLg");
	this.shape_55.setTransform(451.689,486.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#1FBFCC").s().p("AgHAIQgHgIAAgOQAxgNghAtg");
	this.shape_56.setTransform(455.518,481.5981);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#29C6D1").s().p("AgKADIAAgTQAsAYgsAJg");
	this.shape_57.setTransform(546.125,480.825);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#2AC5D5").s().p("AgxACQgDgCAAgFQBbgYAOAhIgGAAQgjAMgXAAQgaAAgMgOg");
	this.shape_58.setTransform(556.25,467.6794);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#0DB6C0").s().p("A3RR2IIlzCQCagXCAgyQBbgjBNgwQBMgvBQgoIAAgKQJDk7I4lIQDdiADnh3QBaGuBqHUQApC4gRBsQgFAAgEACQglARgiAUIAAAKQgFAAgFACQgeAMgeAQIAAAKQgFAAgFABQghALgbASIAAAKQgFAAgEACQgpASgoAUIAAAKQgFAAgFACQgeAMgeAQIAAAKQgFAAgEACQhDAghAAkIAAAKQAAAFgDADQgMARgZAFIAAgFQgeAJgeAQIAAAKQAAAFgCABQgIAEgKAAQgFAAgFABQgUAJgUAKIAAAKIAAAKQgFAAgEACQj1CQkACGIgKABQgeAFgUAOIAAAKQAAAFgCABQkLCakOCWQgFAAgEACQhQAshbAiQiqBajmAiQhtAQhjAAQjaAAiphOgAzwSIIAAAFQBqgGg7AAIgvABgAxuSDQCEAAiEgFg");
	this.shape_59.setTransform(328.5345,749.1287);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#AFECF5").s().p("AAAEYQgEkYAAkXIAJAAIAAIlIAAAKg");
	this.shape_60.setTransform(113.5,683.1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#B5EEF2").s().p("AAAB9QgEh9AAh8IAJAAIAADvIAAAKg");
	this.shape_61.setTransform(113.5,633.6);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#40C3D6").s().p("AgjcgQhBg3g8g8Qm+nBALuKIAAgKIAAolIAAgKIAAhQIAAgKIAAjwIAAgKIAAgKQgMieAAhmIACozIFonnIAARgIAAIIQAbK5IQC5QBZAgBygLQAxgEAugHIolTDQgygXgsgdg");
	this.shape_62.setTransform(173.625,675.725);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#18AFB0").s().p("AgMAeIAAgnQAFgFADgGQACgEAAgFQAEAAABgCIAEgIQATA+gmARIAAgKg");
	this.shape_63.setTransform(235.3002,456.1);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#04ACAC").s().p("AgFAOQgBgCgFAAIAAgKQApg3gfBLg");
	this.shape_64.setTransform(238.1796,443.9243);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#09A9AB").s().p("AgOgJIAAgKIAAgeQAPABgEgVIgBgKQAEAAABACQAbAugNAzQgPgwgBAcQgBAmgIAcQgEAOgCAAQgFAAAHhZg");
	this.shape_65.setTransform(242.5098,426.0669);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#01A5AD").s().p("AADALQgFgRgJgKQAhgjgOBPg");
	this.shape_66.setTransform(244.2042,416.828);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#01ACB4").s().p("AgNgCQgBAAAAgFQAgAPgDAAQgCAAgagKg");
	this.shape_67.setTransform(320.5315,303.9133);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#BBE1E8").s().p("AgEB9IAAkDQAQB6gMCTIgEAAIAAgKg");
	this.shape_68.setTransform(99.5104,258.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#81A150").s().p("AAoAKIhZAAIAAgKIAAgJQAoANA7ABIAAAFIgKAAg");
	this.shape_69.setTransform(120,262.1);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#86B6BD").s().p("AhKAFIAAgJICLAAIAHAAIAAAAIADAAIAAAJIgKAAIgKAAIhAAAIhBAAg");
	this.shape_70.setTransform(106.5,241.6125);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#98D5A6").s().p("AiyR6QACl9gBnVIgC7pIAKAAQAABpAFBpIAFAAIBaAAIAKAAIDbAAIAKAAIAAjIIAAgKIAKAAIAAb9IAAKeIlnHoIABlIg");
	this.shape_71.setTransform(131,389.475);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#92BBC3").s().p("AB9AFIj5AAIgKAAIAAgJIEDAAIAKAAIAAAJIgKAAg");
	this.shape_72.setTransform(161.5,241.6);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#739560").s().p("ACgBuIjbAAIAAgFQg8gBgogOIAAAKIAAAKIgFAAQgFhpAAhoIAAgKIFJAAIAKAAIAAAKIAAAKIAADHIgKAAg");
	this.shape_73.setTransform(131,252.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#D7E4BA").s().p("AgEAoIAAhZIAJAAIAABPIAAAKQAAAFgCACQgDADgEAAIAAgKg");
	this.shape_74.setTransform(113.5,130.1);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#4C8195").s().p("AAAISQgEoSAAoRIAJAAIAAQZIAAAKg");
	this.shape_75.setTransform(0.5,189.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#9ECBDB").s().p("AIrAFIxVAAIgKAAIAAgJIRfAAIAKAAIAAAJIgKAAg");
	this.shape_76.setTransform(56.5,135.6);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#3E8876").s().p("AhPgEICVAAIAKAAIAAAEIgEABQgkAEggAAQgvAAgogJg");
	this.shape_77.setTransform(175,135.5945);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#035B79").s().p("AjbKsQnjiWnniVIAAgKIAAwZIRWAAIAKAAQEIAAEJgFIAAgFIAKAAQBCARBagMIAEAAIAAgFIAKAAIAAAFQEggDEGASQkngFkXAGIqmQOIAAAAIkpgUIgKAAQiEARjkANQgEBDBSAUQBJARA7AkQgqAVBRAXQB6AjB3ApQAWhxADiJIAFAAIAAAKIAAAKIAAEEIAAAKQgFAAgFgBg");
	this.shape_78.setTransform(120,203.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#4B8C7E").s().p("AkIAAQAFAAADgCQACgCAAgFQDzAQEKgHIAKAAIAAAFQkJAFkIAAIAAgKg");
	this.shape_79.setTransform(139.5,135.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#24C3CE").s().p("AgJgJQAoASgoABg");
	this.shape_80.setTransform(571.025,345.1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#27BED7").s().p("AgJAAQgCAAAAgFQAaALgEAAIgUgGg");
	this.shape_81.setTransform(574.1816,336.6797);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#22C1D3").s().p("AgQgCQBJgnhHA6IgDACQgFAAAGgVg");
	this.shape_82.setTransform(570.6984,332.3841);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#1EC1D1").s().p("Ag4AOQgBgKgJgJQBRgkA1AkIgGAAQghAdgmAAQgXAAgYgKg");
	this.shape_83.setTransform(534.75,372.7051);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#23C2CE").s().p("AgVALQBXg2hXA7g");
	this.shape_84.setTransform(553.2125,365.0473);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#1EBED1").s().p("AhZABIgogEIAAgFQAagGAZgDQBogOBmAuQACABAAAFQh3gIhkgMg");
	this.shape_85.setTransform(514,378.9744);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#3B8691").s().p("ABLA1QhMgqhKgtQAAgFgCgEQgDgGgFgFQA5gHAuArIAwArQAaAXgIAHQgFAAgEgCg");
	this.shape_86.setTransform(557.584,320.551);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#318798").s().p("AgPgDQgCgBAAgFQAlATgCAAQgDAAgegNg");
	this.shape_87.setTransform(556.7754,262.0942);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#1FC1CB").s().p("AgKAEQgFgCAAgNQAnAXgJAAQgFAAgUgIg");
	this.shape_88.setTransform(584.6276,268.3134);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#23C0CF").s().p("AgCgVIgBgKIAHA/IgGg1g");
	this.shape_89.setTransform(583.3689,282.3053);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#36C0D3").s().p("EAHRAwNIwjAAIgBgJQg5jzg0j3IgBgKQh5pXiKpFIgBgLQiBqeiMqTIJEwGQBlANB3AHQAAgEgCgBQhmgwhpAOIAhg7ICGgKQApgDAwgRQEghhBLk7QAqiOAlibQA5jyhviTIMsuIQCPB2BiCjQB2DFA/D9IgFAAQgMMVkbJiIAAAVIAAAKQgsA8glBFQk2JJrEC6QBVGsBZGtQAAABAFAAQB2JbCIJKQABABAFABIABAKQBZH9BuIcIgKAAgAu9QWIADAOQAug5g4gIQACAdAFAWgAxkHRIAAAPQAogQgWAAIgSABgAxrF7QAsAUg5g1QgDAbAQAGgAxGF3QApgBgpgTgAxkCSIAABkQAFAAABABIAEAJQArghg1hXIAAAKgAyTDvIAHALQAfgMgpg1QgHAmAKAQgAyzAjIATCNQAFAAAAgBQAaiCgzgUIABAKgAxGAjQgDAbAJAPIAEAJQAcgzgjAAIgDAAgAyMAjQAAAPAIAIIAJAKQAagkgZAAQgHAAgLADgAj+AuIAAAOQAtgKgtgZIAAAVgAjChdQAAAEACAEQAYAaBKgZIAFAAQgIgTgjAAQgYAAgmAKgAmowUQAKAKAAALQBDAbA1gwIAFAAQgagRgiAAQgiAAgpARgAjCxPIAAAEQAugfgCAAQgCAAgqAbgAgE0XQAogCgogTgAAa12QAuAPgvgVQAAAGABAAgAgO2jQgHAbAJgIQAqgjgKAAQgGAAgcAQgAB9+sQAOBygOh8IAAAKgEACCggdQA5AWg+gmQAAAOAFACgEAQpgo/QADAwAbgEQAUg/gTAAQgKAAgVATgEAQHgq6IAEADQAngJgxgWQgHAVANAHgEAOJgs0QBJAChJgIgEANrguAQgLApAVgPQAtghgVAAQgKAAgYAHg");
	this.shape_90.setTransform(570.5,476.55);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#1DBDCE").s().p("Agvg3QgCgEAAgFQB0ARgUBpIgCAGQAAABgFAAQg1gzgihFg");
	this.shape_91.setTransform(569.9778,247.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#1DBDCB").s().p("AnQNrQgwgNARh/IABgKQAmA5gDBdgAHvrUQgwgNARh/IABgKQAmA5gDBdg");
	this.shape_92.setTransform(528.5156,310.6);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#0BB7C1").s().p("EgZQAh2IAKAAIAAgKIAAgeQCdriCQrwQA+lEBDlAMAWGginIBfAAIAKAAQhnIth0IfIgBAKIABAKQAGAbgRADQBRAjCBAAQKcAAJygrIghA7QgZADgaAGIAAAFIAoAFIpEQFIgKAAQoogHoPARQhLFPhCFZQiPLvicLjInWAAQjwAAjvARIgXABQhbAAgRg6gAUhu5QgSB/AwANIAFAAQADhdgmg5IAAAKg");
	this.shape_93.setTransform(347.7,479.4938);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#00ABAD").s().p("AgggBQCDADiDAAg");
	this.shape_94.setTransform(354.3125,258.35);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#02A6B1").s().p("AqbOaQAngQgThAIgEAIQgBACgFAAIAAgKIAAgUQARgNgCgkIAFAAQAFAAABACIAEAIQAghMgqA3IAAgKIAAgdQAahBAJhVIAFgBQgKB9APgxQAIgcABgmQABgdAPAyQANg1gagtQgCgCgFAAIAAgLIAAgUQAVgnAEg8IAFgBIAAgJIAAg9QCVqxCMq7IABgKIAAgKIPOAAMgWFAimIAni6gApBHYQAKALAFASIAFAQQAKg3gOAAQgFAAgLAKgAC4qBQA7AYg9gdQAAAEACABgAH2xEQCFAAiFgEg");
	this.shape_95.setTransform(300.775,367.85);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#47C3D8").s().p("AGqEOQmmjtmijwIAPgBQgegegtgdQHBgOGPAnQA7AGAgAnQAFAjADAjQAPDFhEC2IAFAAQAFAFADAGQACAEAAAFQgFAAgEgCg");
	this.shape_96.setTransform(506.543,289.9168);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#5693A3").s().p("ADmCBQj5h5jkiOQBpAQBWAhQAEABAGAAQBmBSBsBLQAEACAFAAQAsAeAeAdIgOABQAAgFgDgBg");
	this.shape_97.setTransform(441.75,255.6);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#92CACE").s().p("AJEAFI79AAIAAgJIb9AAICCAAQD6AAD6AEIAAAFIp2AAg");
	this.shape_98.setTransform(296,241.6);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#028699").s().p("A7BJXQhRgXAqgVQg7gkhIgRQhTgUAEhDQDkgNCEgRIAKAAIEpAUIgHAAIiMAAIAAAKIAAAKIgFAAQgDCJgWBxQh3gph6gjgARDGVI79AAIgKAAIkEAAIgKAAIlKAAIgDAAIKowOQEWgGEnAFQkGgSkgADIAAgFIKxAAIAKAAQMGgBLCgTIAKAAQgSAYBYAFIAeABIAAgKQCYAACSgCIr2QlIhBAAIhBAAg");
	this.shape_99.setTransform(244.8634,200.6);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#1EBACC").s().p("AgggJQCBASh3ABQgQAAAGgTg");
	this.shape_100.setTransform(610.2757,158.125);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#1FBFD0").s().p("AAsAgQgzgXgjgmQgDgDAAgFQBmAHgNBEg");
	this.shape_101.setTransform(643.5679,167.85);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#1CC3C9").s().p("AgPgDQA8gEg1AMIAAAAQgCAAgFgIg");
	this.shape_102.setTransform(639.6178,170.495);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#CAE05B").s().p("AcgKQQjrAJkBAEQiRACiYAAIAAAKIgegCQhZgEATgYIgKAAQrCATsFABIgKAAIqyAAIgKAAIgKAAIiWAAIgKAAIgKAAQkLAHjzgRIAAgKIAAhQIAAgKIAAhaIAAgKIAAgKQAwtOKHjvQCCgxClAEQHhAJFJCsQJbEkIyFGQBYAzBMA8QDPBsDJB0QACABAAAFQC6BfCwBnQADACAFAAIAAAKIAAAKQhAgchDADg");
	this.shape_103.setTransform(309.5,68.0382);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#0EAFBB").s().p("AJBPGQgGgDgFgFQAHgIgagXIgwgrQgugrg5AHIgFAAQBEi2gPjGQgCgjgGgjQgggng6gGQmQgnnBAOQgFAAgDgDQhthMhnhRQgFAAgFgCQhVgghpgQIAAgFQj6gFj6AAIL1wlQEBgEDrgJQBDgDBAAcIAAgKIAAgKIAVAIQAEACAFAAQDiARD9gHIAKAAQJbAfFZEgIssOIQBvCSg5DyQglCcgrCOQgFAAgEgCgAHKE6QBEAehGgkQAAAFACABgAIuB1QAiBGA2AzQAFAAAAgBIABgGQAVhrh1gQQAAAFACAEgAKPg9QgRB+AwANIAFAAQAEhdgng4IgBAKgAUTqOQAjAnA0AYIAAAFQANhFhngGQAAAFADACgAUGpZQAFAJACAAQAogKgYAAIgXABgAParHQB3gBiBgTQgHAUARAAg");
	this.shape_104.setTransform(509.4,230.3355);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#8FF5F7").s().p("Aj0gFQD0AAD1AFIAAAEIgKAAQhMAChJAAQirAAifgLg");
	this.shape_105.setTransform(532.5,135.7125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Símbolo3, new cjs.Rectangle(0,0,922.4,871.2), null);


(lib.Símbolo2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ACbGyQgYglgRgtQgFAAAAgBQgFgTAAgUIgFAAQgFk/AAlAIAKAAIAAgKIAAgeIAKAAIAAgKIAAgoQBZjEEPgOIAKAAIAAgKIBGAAIAKAAIR+AAIAKAAQAtAAAtAFIAAAFQFLAFAnEnIAAAKQASElgNE8IgFAAIAAAKIAABGQgPAigTAcQgbAogjAfQhBA4hbAOQliAzmUgJQjSgFjQAUQhDAGg8AAQlZAAiBjMgAI+lvQAAAFgBAAQgqAHgbASIAAAKIAAAKIAAJXIAAAKQASAvA+ABQG4ACG4AOQC/AHB3gzQAjiMAAi9QAAi4gjiIQgFgKgFAAQnIgVnXAAQiDAAiEABgA2bJaIikioQjvj5jlkFQjSjviykQQAWgmA6gCIAKAAIAAgKQBzAABzAFIAAAFQCMAZBDBpQBEBqBSBhQDzEgD6EWQGEnNGgmyQAJgLAbAHIAAgKQB4AAB4AFIAAAFQCaAehlBwQhDBKg+BLQlOGNllF1IijCoIAAAFQhuAFhuAAIgKABQgNACgMAAQgdAAgQgNgEBB2AJaQgFAAgDgCQiChSiAhUQjGiBjEiFQgFAAgDADQi5CGjCB9QiGBWiLBSIAAAFQjAANiogSIgTgKQgqgXAfgZQBGg3BHg3QEwjoFFjRQjeijjsiWQhPgyhRgoQh4g6g0h3QAegeAygJIAKgBIAAgKQCMAACMAFIAAAFQDMBMCfB5QCjB7CuBuQFIjoFrjEQAEgCAFAAIAAgKQCMAACMAFIAAAFQA+gCAbAjQAIAKgRAOQlxEmmREDQDICkDlCKQBwBEBkBRQBDA4A+A+QARARgKAKQgTAVgmACIAAAFQhOAFhKAAQhnAAhfgKgEgzBAJaQAAgFgCgBQhzhQhyhSQkSjEkJjOIAAgKINwAAIAKAAQA+AHAQglQACgEAAgFIAAgKIAAjwIAKAAQAHgbgEgIQgNgdgVgBQosggpHAHIAAAKQAHGPgMF+IgFCAQAAAFgBAFQgLAcgmACIAAAFQiYANiAgSQgFAAgEgBQghgMgIglIgFAAIgBh2QgEn0AAn1IAKAAIAAgKIAAgKQAWgmA6gCIAKAAIAAgKQLBAALBAFIAAAFQF/gRBCEpIABAKQASCegNC1IgFAAIgBAKQgzECkqAMIAAAFQgtAFgtAAQBZBIBcBGQBrBSBuBQQACABAAAFIAAAFQh6AFh1AAQilAAicgKg");
	this.shape.setTransform(462.5755,63.7862);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Símbolo2, new cjs.Rectangle(0,0,925.2,127.6), null);


(lib.Símbolo1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#40C3D6").s().p("EgpwACTQFWAHE9gWIABgFIAAgKIAAjvIgBgFQk4gXlRAIIgFgBQgFgxAAgyQAFgFAGgDQAEgCAFAAQCbAACagJQEUgQC5BBQASAWAGAlQAqDshWCaQiaAujZgKQh3gGh2ARQgaAEgWAAQiHAAAViNgEg46ACdIgFAAQgFjHAAjIIAKAAIAAgKQBNgIA1AQQAFACAFAAQARCngHDAIAAAKQBfAjCRgBQCVAABlgiIAAgKIAAldIAKAAIAAgKIAAgKQBGAABFAFIABAFQARCYgHCxIAAAKIgBAKQgEBLgjAtQg7AfhRADQiMAGiLAPQgqAEglAAQjKAAg8iBgEAk+AEbQiEgJhsgJQh6gKgHh2IgFAAQgFizAAi0IAKAAIAAgKIAAgKQA6gRBRAMIABAFQARCxgCDKIAFAAQDjARD9gMIAAgFQAKi9AIi+QABgRAVAHQBTgNAiAjQADADAAAFQAHDZgRDAIAAAKQh3BZjbAAQgoAAgrgDgEAs9ADZQDCjhC3jsQADgDAAgFICMAAIAKAAQDFDzCtEFIgKAFIgBAFQgsAFgtAAQgFAAgDgDQi8imiQjSQgFAAgCACIklFvQgFAAgFABQgmAOgdAAQg7AAgYg3gARnELQAAgFgBAAQhagTgJhgQFHAHEugbQAGAAAFgKQg5hYiuAYQgdAEgeAAIgKAAQg1AHgbgRIgKAAQi+AOgyh7IgFgBQgFg2AAg3IAKAAQATg9BHgJQEOgjFAAPQAAAFABAAQBTAPAQBQQgaAihLgEQizgKizgPQiJgKgsBBQgCAbAWABQESAXEKAdQAAAFACABQAtAUAXArIABAJQAXBcgsBFQgbAXgrAFQjCAajbAAQhXAAhagEgAxYELQAAgFgCgBQhQgWgIhcIgFAAQgFiRAAiQIAKAAIAAgKIAAgKQBwiUE2AcID4AWQB+AMAEB+QARB6gMCSIgFABQAAAFgCAEQgIAfgKAeQgXARgcAEQjcAgj4AAQhUAAhXgDgAwciEIAAAKQgICSASB7QA4ANBJADQDIAICXgiIAFgBQAMiSgRh6IAAgFQhrgFhnAAQiQAAiIAKgA5AD0QgCgCAAgFIAAnVIAAgKQA6gRBRAMIABAFQAZD5gjD4QAAAHgKAFQgWADgTAAQgzAAgagagEg8hAECQgEgBgFAAQiUi2iRi5QgCgCgFAAQiUDJi5CjQgRAPgeAAIgUAAQgwADgCgrIAAgKQC9jmC8jnQADgDAAgFICCAAIAKAAQDODqCnENQAIAMgVgGQgfANgfAAQgdAAgegMgEA+JAEBIgKgBQg7gFgVgsQgFAAAAgBQgojIAPj4IAKAAIAAgKQBBAABAAFIABAFQARCxgCDKIAFAAQEsAKEqAaQATACgBAqQgBAjgZAFIAAAFQiIAFiFAAQi5AAiwgKgALMD+QgljrAIkFQA6gRBRAMIABAFQAZD5geD5IgFABIgBAFQgsAFgtAAQgLgKAAgDgABZEIQizipiOjPQgFAAgBgCQgSgigagYQAAgFgCgCQghgTgFgsQA6gRBSAGIAKABQBdBrBTBzQADADAAAFQAVAIAHAVQACAFAAAFQAeAUASAfQACAEAAAFQASAMAKATQACAEAAAFQAvgNARguQABgBAFAAIAAgKQAZgUASgbQACgCAFAAIAAgKQAjgjAcgrQACgCAFAAIAAgKQARgRAQgVQACgCAFAAIAAgKIAKAAIAAgKQAQABgBgVIAFAAQAAgFACgEQArhRCRAUQAFAFgBACQhUCjh0CFQgqAwgbA3Qg2BtiXAEQgFAAgDgDg");
	this.shape.setTransform(463.3026,28.7681);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Símbolo1, new cjs.Rectangle(0,0,926.6,57.6), null);


(lib.Interpolación3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Mapadebits13();
	this.instance.setTransform(-223.25,-167.2,1.724,1.724);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-223.2,-167.2,446.5,334.5);


(lib.Interpolación2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Mapadebits12();
	this.instance.setTransform(-211.5,-129.5,1.5382,1.4153);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-211.5,-129.5,423,259);


(lib.Símbolo1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_1();
	this.instance.setTransform(16.3,8.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Símbolo1_1, new cjs.Rectangle(16.3,8.9,229.5,53.5), null);


// stage content:
(lib.LOGOANIMADOPARAWEBcanvas = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_5
	this.instance = new lib.Símbolo1_1();
	this.instance.setTransform(153,290.7,1,1,0,0,0,131,34.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(51).to({_off:false},0).to({y:216.3},8,cjs.Ease.get(1)).wait(59));

	// Símbolo_1
	this.instance_1 = new lib.Símbolo1();
	this.instance_1.setTransform(157.4,442.15,0.1629,0.1629,0,0,0,463.2,28.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(42).to({_off:false},0).to({y:179.85},14,cjs.Ease.get(1)).wait(1).to({regX:463.3,regY:28.8},0).wait(60).to({regX:463.2,regY:28.9},0).wait(1));

	// Símbolo_2
	this.instance_2 = new lib.Símbolo2();
	this.instance_2.setTransform(157.45,421.55,0.1629,0.1629,0,0,0,462.7,63.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(37).to({_off:false},0).to({y:160.05},14,cjs.Ease.get(1)).wait(1).to({regX:462.6,regY:63.8},0).wait(65).to({regX:462.7,regY:63.9},0).wait(1));

	// Símbolo_3
	this.instance_3 = new lib.Símbolo3();
	this.instance_3.setTransform(157.2,329.75,0.1629,0.1629,0,0,0,461.1,435.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(33).to({_off:false},0).to({y:76.25},14,cjs.Ease.get(1)).wait(1).to({regX:461.2,regY:435.6,y:76.3},0).wait(69).to({regX:461.1,regY:435.3,y:76.25},0).wait(1));

	// Capa_1
	this.instance_4 = new lib.Símbolo5();
	this.instance_4.setTransform(171,124.05,1,1,0,0,0,201,142);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(42).to({_off:false},0).to({alpha:1},8).wait(68));

	// Capa_2
	this.instance_5 = new lib.Interpolación3("synched",0);
	this.instance_5.setTransform(93.25,119.2);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(21).to({_off:false},0).to({x:119.9,alpha:1},6).to({x:213.25},21).wait(70));

	// Capa_8
	this.instance_6 = new lib.Interpolación2("synched",0);
	this.instance_6.setTransform(196.5,120.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({x:96.5},25).wait(93));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("A4/1FMAx/AAAMAAAAqLMgx/AAAg");
	this.shape.setTransform(150,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A4/VGMAAAgqLMAx/AAAMAAAAqLg");
	this.shape_1.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(118));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(20,77,416.5,369.8);
// library properties:
lib.properties = {
	id: '3204C158B9E6814A9E549180FC4BA423',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/LOGO ANIMADO PARA WEB canvas_atlas_1.png?1707229288056", id:"LOGO ANIMADO PARA WEB canvas_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['3204C158B9E6814A9E549180FC4BA423'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;